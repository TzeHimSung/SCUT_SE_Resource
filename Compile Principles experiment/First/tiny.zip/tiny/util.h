#ifndef UTIL_H
#define UTIL_H
 
#include "globals.h"
 
void printToken(TokenType token, char* tokenString);
 
TokenType getToken(void);
 
#endif